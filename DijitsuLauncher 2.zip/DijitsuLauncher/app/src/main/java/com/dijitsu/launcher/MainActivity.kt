package com.dijitsu.launcher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import kotlin.concurrent.thread

class MainActivity : Activity() {

    // Üstteki büyük kutularda görünecek uygulamalar (ad içinde geçen kelimeler)
    private val favoriteKeys = listOf("youtube", "netflix", "play store", "chrome")

    // Listede gizlenecek uygulamalar (ad içinde geçen kelimeler)
    private val hiddenKeys = listOf("boot video", "nperf", "sistem")

    private lateinit var greeting: TextView
    private lateinit var favRow: RecyclerView
    private lateinit var grid: RecyclerView
    private lateinit var pillSettings: TextView
    private lateinit var pillOriginal: TextView
    private lateinit var favAdapter: AppAdapter
    private lateinit var gridAdapter: AppAdapter
    private var originalIntent: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        greeting = findViewById(R.id.greeting)
        favRow = findViewById(R.id.favRow)
        grid = findViewById(R.id.appGrid)
        pillSettings = findViewById(R.id.pillSettings)
        pillOriginal = findViewById(R.id.pillOriginal)
        val pillWifi = findViewById<TextView>(R.id.pillWifi)

        favRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favAdapter = AppAdapter(this, R.layout.item_fav, emptyList()) { open(it.intent) }
        favRow.adapter = favAdapter

        grid.layoutManager = GridLayoutManager(this, 7)
        gridAdapter = AppAdapter(this, R.layout.item_app, emptyList()) { open(it.intent) }
        grid.adapter = gridAdapter

        pillWifi.setOnClickListener { open(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        pillSettings.setOnClickListener { open(Intent(Settings.ACTION_SETTINGS)) }
        pillOriginal.setOnClickListener { originalIntent?.let { open(it) } }

        listOf(pillWifi, pillSettings, pillOriginal).forEach { it.enableFocusScale(1.06f) }
    }

    override fun onResume() {
        super.onResume()
        updateGreeting()
        loadApps()
    }

    private fun updateGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when (hour) {
            in 5..11 -> "GÜNAYDIN"
            in 12..17 -> "İYİ GÜNLER"
            in 18..22 -> "İYİ AKŞAMLAR"
            else -> "İYİ GECELER"
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val own = packageName
        thread {
            val all = AppRepository.loadApps(pm, own)
            val original = all.firstOrNull { it.label.contains("launcherfall", ignoreCase = true) }
            val visible = all.filter { app ->
                app !== original && hiddenKeys.none { app.label.contains(it, ignoreCase = true) }
            }
            val favs = favoriteKeys
                .mapNotNull { key -> visible.firstOrNull { it.label.contains(key, ignoreCase = true) } }
                .distinct()

            runOnUiThread {
                originalIntent = original?.intent
                pillOriginal.visibility = if (original != null) View.VISIBLE else View.GONE
                favAdapter.submit(favs)
                gridAdapter.submit(visible)
                grid.scrollToPosition(0)

                if (currentFocus == null) {
                    favRow.postDelayed({
                        val first = favRow.findViewHolderForAdapterPosition(0)?.itemView
                        (first ?: pillSettings).requestFocus()
                    }, 200)
                }
            }
        }
    }

    private fun open(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // Ana ekranda geri tuşu hiçbir şey yapmasın
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // bilerek boş
    }
}
