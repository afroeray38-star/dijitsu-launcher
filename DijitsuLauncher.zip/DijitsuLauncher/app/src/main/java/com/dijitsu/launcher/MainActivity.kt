package com.dijitsu.launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var adapter: AppAdapter
    private lateinit var greeting: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        greeting = findViewById(R.id.greeting)

        val grid = findViewById<RecyclerView>(R.id.appGrid)
        grid.layoutManager = GridLayoutManager(this, 6)
        adapter = AppAdapter(this, emptyList()) { launch(it) }
        grid.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        updateGreeting()
        loadApps()
    }

    private fun updateGreeting() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when (hour) {
            in 5..11 -> "Günaydın"
            in 12..17 -> "İyi günler"
            in 18..22 -> "İyi akşamlar"
            else -> "İyi geceler"
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val own = packageName
        thread {
            val apps = AppRepository.loadApps(pm, own).toMutableList()

            val settingsIcon = ContextCompat.getDrawable(this, R.drawable.ic_settings)
            val wifiIcon = ContextCompat.getDrawable(this, R.drawable.ic_wifi)
            apps.add(
                0,
                AppInfo(
                    "Ağ Ayarları", wifiIcon,
                    Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            )
            apps.add(
                0,
                AppInfo(
                    "Ayarlar", settingsIcon,
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            )

            runOnUiThread { adapter.submit(apps) }
        }
    }

    private fun launch(app: AppInfo) {
        try {
            startActivity(app.intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // Ana ekranda geri tuşu hiçbir şey yapmasın
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // bilerek boş
    }
}
