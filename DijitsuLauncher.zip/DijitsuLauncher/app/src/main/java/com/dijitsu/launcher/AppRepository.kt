package com.dijitsu.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable

data class AppInfo(
    val label: String,
    val icon: Drawable?,
    val intent: Intent
)

object AppRepository {

    fun loadApps(pm: PackageManager, ownPackage: String): List<AppInfo> {
        val result = LinkedHashMap<String, AppInfo>()

        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            val activities = pm.queryIntentActivities(query, 0)
            for (ri in activities) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ownPackage || result.containsKey(pkg)) continue
                val launch = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(category)
                    setClassName(pkg, ri.activityInfo.name)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                }
                result[pkg] = AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    icon = ri.loadIcon(pm),
                    intent = launch
                )
            }
        }

        return result.values.sortedBy { it.label.lowercase() }
    }
}
