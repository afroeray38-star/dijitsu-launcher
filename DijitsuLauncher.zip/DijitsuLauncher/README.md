# Dijitsu Ana Ekran (Launcher)

Android TV / Android 11 için basit, koyu mavi temalı ana ekran uygulaması.
Saat, tarih, selamlama, Ayarlar / Ağ Ayarları kısayolları ve TV'deki tüm uygulamaların ızgarası var.
Kumanda yön tuşlarıyla gezilir, OK ile açılır.

## APK'yı derlemek (bilgisayar kurmadan, GitHub ile)

1. github.com'da ücretsiz hesap aç, yeni bir repo oluştur (ör. `dijitsu-launcher`).
2. Bu klasörün içindeki her şeyi (gizli `.github` klasörü dahil) repoya yükle.
3. Repoda **Actions** sekmesine gir, **APK Derle** akışını çalıştır (Run workflow).
4. 3-5 dakika sonra bitince çalışmanın içinden **DijitsuLauncher-apk** dosyasını indir, zip'in içinden `app-debug.apk` çıkar.

## APK'yı derlemek (Android Studio ile)

1. Android Studio'yu kur, bu klasörü "Open" ile aç.
2. Gradle senkronu bitince **Build > Build APK(s)** de.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## TV'ye kurmak

1. APK'yı USB belleğe at, TV'ye tak.
2. TV'deki dosya yöneticisi/APK yükleme uygulamasıyla `app-debug.apk` dosyasını aç, "bilinmeyen kaynaklardan yüklemeye" izin ver.
3. Kurulumdan sonra **Dijitsu Ana Ekran**'ı uygulama listesinden aç.

## Ana ekran olarak ayarlamak

Bu TV'nin kendi arayüzü özel olduğu için Home tuşu büyük ihtimalle kendi arayüzünü açmaya devam eder.
Çözüm: Ayarlar'dan varsayılan ana ekran/launcher seçeneğine bak. Yoksa uygulamayı elle açman gerekir.

## Özelleştirme

- Renkler: `app/src/main/res/drawable/bg_main.xml` ve `bg_card.xml`
- Sütun sayısı: `MainActivity.kt` içinde `GridLayoutManager(this, 6)`
- Yazılar: `activity_main.xml`
